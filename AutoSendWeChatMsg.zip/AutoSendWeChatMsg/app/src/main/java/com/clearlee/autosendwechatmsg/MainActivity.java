package com.clearlee.autosendwechatmsg;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.view.accessibility.AccessibilityManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;


import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.zip.InflaterOutputStream;


import static android.content.Intent.FLAG_ACTIVITY_NEW_TASK;
import static com.clearlee.autosendwechatmsg.AutoSendMsgService.SEND_STATUS;
import static com.clearlee.autosendwechatmsg.AutoSendMsgService.SEND_SUCCESS;
import static com.clearlee.autosendwechatmsg.AutoSendMsgService.hasSend;
import static com.clearlee.autosendwechatmsg.WechatUtils.CONTENT;
import static com.clearlee.autosendwechatmsg.WechatUtils.NAME;

/**
 * Created by Ningrong Chen
 * 2020/4/8
 */
public class MainActivity extends AppCompatActivity {
    String baseurl = "https://tkmp.tmtreading.cn/app/index.php?i=2&t=2&v=1.0.0&from=wxapp&c=entry&a=wxapp&do=GetGoodPoster&&sign=28ac5abff924bfa149a2e6343e173530";
    String imageurl = "https://tkmp.tmtreading.cn/addons/nets_haojk/cache/ee3fe8039dba118999654a56021ebca7.jpg";
    private static final int SAVE_SUCCESS = 0;//保存图片成功
    private static final int SAVE_FAILURE = 1;//保存图片失败
    private static final int SAVE_BEGIN = 2;//开始保存图片



    private TextView start, sendStatus;
    private EditText sendName, sendContent;
    private AccessibilityManager accessibilityManager;
    private String name, content;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        start = (TextView) findViewById(R.id.testWechat);
        sendName = (EditText) findViewById(R.id.sendName);
        sendContent = (EditText) findViewById(R.id.sendContent);
        sendStatus = (TextView) findViewById(R.id.sendStatus);
        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkAndStartService();
            }
        });
    }

    private int goWecaht() {
        try {
            setValue(name, content);
            hasSend = false;
            Intent intent = new Intent();
            intent.setFlags(FLAG_ACTIVITY_NEW_TASK);
            intent.setClassName(WeChatTextWrapper.WECAHT_PACKAGENAME, WeChatTextWrapper.WechatClass.WECHAT_CLASS_LAUNCHUI);
            startActivity(intent);

            while (true) {
                if (hasSend) {
                    return SEND_STATUS;
                } else {
                    try {
                        Thread.sleep(500);
                    } catch (Exception e) {
                        openService();
                        e.printStackTrace();
                    }
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
            return SEND_STATUS;
        }
    }


    private void openService() {
        try {
            //打开系统设置中辅助功能
            Intent intent = new Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivity(intent);
            Toast.makeText(MainActivity.this, "找到微信自动发送消息，然后开启服务即可", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void checkAndStartService() {
        accessibilityManager = (AccessibilityManager) getSystemService(ACCESSIBILITY_SERVICE);

        name = sendName.getText().toString();
        content = sendContent.getText().toString();

        if (TextUtils.isEmpty(name)) {
            Toast.makeText(MainActivity.this, "联系人不能为空", Toast.LENGTH_SHORT);
        }
        if (TextUtils.isEmpty(content)) {
            Toast.makeText(MainActivity.this, "内容不能为空", Toast.LENGTH_SHORT);
        }

        if (!accessibilityManager.isEnabled()) {
            openService();
        } else {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    // Get image url
                    int count = 0;
                    while (sentPost() && count < 5) {
                        count++;
                        // url to bitmap , bitmap to file , store at
                        mHandler.obtainMessage(SAVE_BEGIN).sendToTarget();
                        Log.d("URL", "start");
                        Bitmap targetPhotoBM = returnBitMap(imageurl);
                        if (targetPhotoBM != null) {
                            Log.d("URL", "bitmap not null");
                            saveBitmapFile(targetPhotoBM);
                        } else {
                            Log.d("URL", "bitmap is null");
                        }
                    }
                    statusHandler.sendEmptyMessage(goWecaht());
                }
            }).start();
        }

    }

    Handler mHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case SAVE_BEGIN:
                    Log.d("URL","开始保存图片...");
                    break;
                case SAVE_SUCCESS:
                    Log.d("URL","图片保存成功,请到相册查找");
                    break;
                case SAVE_FAILURE:
                    Log.d("URL","图片保存失败,请稍后再试...");
                    break;
            }

        }
    };

    Handler statusHandler = new Handler() {
        @Override
        public void handleMessage(Message msg) {
            super.handleMessage(msg);
            setSendStatusText(msg.what);
        }
    };

    private void setSendStatusText(int status) {
        if (status == SEND_SUCCESS) {
            sendStatus.setText("微信发送成功");
        } else {
            sendStatus.setText("微信发送失败");
        }
    }

    public void setValue(String name, String content) {
        NAME = name;
        CONTENT = content;
        hasSend = false;
    }

    public boolean sentPost() {
        final boolean[] result = {false};
        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    URL url = new URL(baseurl);
                    String end = "\r\n";
                    String twoHyphens = "--";
                    String boundary = "----WebKitFormBoundary7MA4YWxkTrZu0gW";
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setRequestMethod("POST");
                    conn.setRequestProperty("Content-Type","multipart/form-data;boundary=" + boundary);
                    conn.setRequestProperty("Charset", "UTF-8");
                    conn.setDoOutput(true);
                    conn.setDoInput(true);
                    conn.setUseCaches(false);
                    DataOutputStream dos = new DataOutputStream(conn.getOutputStream());
                    dos.writeBytes(end + twoHyphens + boundary+end);
                    dos.writeBytes("Content-Disposition: form-data; name=\"m\""+end + end +"nets_haojk" + end );
                    dos.writeBytes(twoHyphens+boundary+twoHyphens+end);
                    BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                    String temp = "";
                    StringBuilder stringBuilder = new StringBuilder();
                    while ((temp = in.readLine())!= null) {
                        stringBuilder.append(temp);
                    }
                    JSONObject json = new JSONObject(stringBuilder.toString().trim());
                    JSONObject data = json.getJSONObject("data");
                    if (data != null) {
                        imageurl = data.get("res").toString();
                        result[0] = true;
                    }


                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        thread.start();
        return result[0];
    }

    public final static Bitmap returnBitMap(final String url){
        Log.d("URL", "Start produce bitmap");
        URL myFileUrl;
        Bitmap bitmap = null;
        try {
            myFileUrl = new URL(url);
            HttpURLConnection conn;
            conn = (HttpURLConnection) myFileUrl.openConnection();
            conn.setDoInput(true);
            conn.connect();
            InputStream is = conn.getInputStream();
            bitmap = BitmapFactory.decodeStream(is);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;

    }

    public void saveBitmapFile(Bitmap bitmap){
        //String SAVE_REAL_PATH = "/storage/self/primary/cache/images/";
        String SAVE_REAL_PATH = Environment.getExternalStorageDirectory()+"/DCIM/Camera/";
        Log.d("URL", "SAVE_REAL_PATH " + SAVE_REAL_PATH);
        File dirfile=new File(SAVE_REAL_PATH);//将要保存图片的路径
        if (!dirfile.exists()) {
            Log.d("URL", dirfile.toString() + "Don't exist");
            dirfile.mkdir();
        }
        Date date = new Date();
        DateFormat format = new SimpleDateFormat("yyyyMMdd");
        String time = format.format(date);

        String fileName = "IMG_" +time+ "_" + System.currentTimeMillis()+ ".jpg";
        Log.d("URL" ,"FileName" + fileName);
        File file = new File(dirfile,fileName);
        Log.d("URL" , file.toString());
        try {
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(file));
            bitmap.compress(Bitmap.CompressFormat.JPEG, 100, bos);
            bos.flush();
            bos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        // 其次把文件插入到系统图库
        try {
            MediaStore.Images.Media.insertImage(this.getContentResolver(),
                    file.getAbsolutePath(), fileName, null);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            mHandler.obtainMessage(SAVE_FAILURE).sendToTarget();
            return;
        }

        // 最后通知图库更新
        Intent intent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        Uri uri = Uri.fromFile(file);
        intent.setData(uri);
        this.sendBroadcast(intent);
        mHandler.obtainMessage(SAVE_SUCCESS).sendToTarget();

    }


}
