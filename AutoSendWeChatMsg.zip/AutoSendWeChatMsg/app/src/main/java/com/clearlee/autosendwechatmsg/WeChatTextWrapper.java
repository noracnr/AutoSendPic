package com.clearlee.autosendwechatmsg;

/**
 * Created by Ningrong Chen on 2020/4/8.
 * 微信版本7.0.13
 */

public class WeChatTextWrapper {

    public static final String WECAHT_PACKAGENAME = "com.tencent.mm";


    public static class WechatClass{
        //微信首页
        public static final String WECHAT_CLASS_LAUNCHUI = "com.tencent.mm.ui.LauncherUI";
        //微信联系人页面
        public static final String WECHAT_CLASS_CONTACTINFOUI = "com.tencent.mm.plugin.profile.ui.ContactInfoUI";
        //微信聊天页面
        public static final String WECHAT_CLASS_CHATUI = "android.widget.LinearLayout";
        //相册页面
        public static final String WECAHT_CLASS_GALLERYUI = "com.tencent.mm.plugin.gallery.ui.AlbumPreviewUI";
    }


    public static class WechatId{
        /**
         * 通讯录界面
         */
        public static final String WECHATID_CONTACTUI_LISTVIEW_ID = "com.tencent.mm:id/f4";
        public static final String WECHATID_CONTACTUI_ITEM_ID = "com.tencent.mm:id/dux";
        public static final String WECHATID_CONTACTUI_NAME_ID = "com.tencent.mm:id/dux";

        /**
         * 聊天界面
         */
        public static final String WECHATID_CHATUI_EDITTEXT_ID = "com.tencent.mm:id/ak7";
        public static final String WECHATID_CHATUI_USERNAME_ID = "com.tencent.mm:id/g7_";
        public static final String WECHATID_CHATUI_BACK_ID = "com.tencent.mm:id/rn";
        public static final String WECHATID_CHATUI_SWITCH_ID = "com.tencent.mm:id/am9";
        public static final String WECHATID_CHATUI_PLUS_ID = "com.tencent.mm:id/ajp";
        public static final String WECHATID_CHATUI_PHOTO_ID = "com.tencent.mm:id/p9";
        public static final String WECHATID_PHOTOUI_ID = "com.tencent.mm:id/dj4";
    }

}
